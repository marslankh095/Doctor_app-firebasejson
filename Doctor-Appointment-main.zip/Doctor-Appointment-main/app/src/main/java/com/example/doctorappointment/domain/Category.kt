package com.example.doctorappointment.domain

data class Category(
    var Id : Int =0,
    var Name : String = "",
    var Picture : String = ""
)
